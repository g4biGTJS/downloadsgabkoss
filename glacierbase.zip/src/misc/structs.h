#pragma once
#include <windows.h>

namespace rbx {
	struct vector2_t {
		float x, y;
	};

	struct vector3_t {
		float x, y, z;
	};

	struct vector4_t {
		float x, y, z, w;
	};

	struct matrix3_t {
		float data[9]; // [3][3]
	};

	struct matrix4_t {
		float data[16]; // [4][4]
	};
}