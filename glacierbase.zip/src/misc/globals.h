#pragma once
#include <windows.h>
#include <vector>
#include <thread>
#include <chrono>
#include <mutex>

#include "imgui/imgui.h"

#include "classes/instance/instance.h"
#include "classes/entity/entity.h"
#include "classes/players/players.h"
#include "classes/camera/camera.h"
#include "classes/task_scheduler/task_scheduler.h"

#define sleep_ms(ms) std::this_thread::sleep_for(std::chrono::milliseconds(ms));

namespace rbx {
	namespace globals {
		inline datamodel g_datamodel;
		inline visual_engine g_visual_engine;
		inline players g_players_service;
		inline workspace g_workspace;
		inline camera g_camera;

		inline HWND our_window;
		inline bool vsync = true;
	}

	namespace cheats {
		namespace visuals {
			inline bool esp = false;
			inline int esp_style = 0;
			inline bool filled = false;
			inline bool skeleton = false;
			inline bool tracers = false;
			inline bool health = false;
			inline bool name = false;
			inline bool distance = false;
			inline bool head_dot = false;
			inline bool outline = false;

			inline float min_health = 20.0f; // 20 health or more
			inline float max_distance = 1000.0f; // 1000 studs or less

			inline const char* flags[] = { "Self", "Team", "Alive", "Health", "Distance" };
			inline bool flags_vals[] = { true, true, true, false, true };

			inline ImColor main_color = ImColor(173, 102, 255);
		}

		namespace combat {
			inline bool aimbot = false;
			inline int aimbot_type = 0;
			inline bool fov = false;
			inline float fov_radius = 250.0f;
			inline bool use_fov = false;

			inline float min_health = 20.0f; // 20 health or more
			inline float max_distance = 1000.0f; // 1000 studs or less

			inline const char* flags[] = { "Team", "Alive", "Health", "Distance" };
			inline bool flags_vals[] = { true, true, false, false };
		}

		namespace player {
			inline bool speed = false;
			inline float speed_val = 50.f;
			inline bool jump = false;
			inline float jump_val = 70.f;
			inline bool fly = false;
			inline float fly_val = 50.f;
		}
	}
}