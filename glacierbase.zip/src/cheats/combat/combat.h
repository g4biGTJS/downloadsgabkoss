#pragma once
#include "cache/cache.h"

#include "imgui/imgui.h"
#include "imgui/imgui_impl_dx11.h"
#include "imgui/imgui_impl_win32.h"

class combat {
private:
	static void perform_mouse_aimbot(rbx::vector2_t screen);
	static void perform_camera_aimbot(rbx::vector3_t target);
public:
	static void combat_thread();
};