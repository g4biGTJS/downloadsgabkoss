#pragma once
#include "classes/instance/instance.h"
#include "classes/players/players.h"
#include "classes/workspace/workspace.h"

namespace rbx {
	struct datamodel : instance {
		players get_players_service();
		workspace get_workspace();
	};
}