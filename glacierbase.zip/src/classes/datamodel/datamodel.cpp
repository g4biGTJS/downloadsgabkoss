#include "datamodel.h"

rbx::players rbx::datamodel::get_players_service() {
	auto players_service = this->find_first_child("Players");
	return players(players_service.self);
}

rbx::workspace rbx::datamodel::get_workspace() {
	auto w = this->find_first_child("Workspace");
	return workspace(w.self);
}