#include "players.h"

rbx::entity rbx::players::get_local_player() {
	auto lp = read<uint64_t>(this->self + offsets::LocalPlayer);
	return entity(lp);
}

std::vector<rbx::entity> rbx::players::get_active_players() {
	std::vector<entity> plrs;
	for (auto p : this->get_children()) {
		auto child = entity(p.self);
		plrs.push_back(child);
	}
	return plrs;
}

int rbx::players::get_player_count() {
	auto count = this->get_children().size();
	return count;
}