#include "workspace.h"

rbx::camera rbx::workspace::get_current_camera() {
	auto cam = this->find_first_child("Camera");
	return camera(cam.self);
}