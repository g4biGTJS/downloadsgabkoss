#pragma once
#include "classes/instance/instance.h"
#include "classes/camera/camera.h"

namespace rbx {
	struct workspace : instance {
		camera get_current_camera();
	};
}