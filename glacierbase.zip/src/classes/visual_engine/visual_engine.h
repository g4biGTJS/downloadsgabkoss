#pragma once
#include "classes/instance/instance.h"

namespace rbx {
	struct visual_engine : instance {
		matrix4_t get_view_matrix();
		vector2_t get_dimensions();
		vector2_t world_to_screen(const vector3_t& world);
	};
}