#include "task_scheduler.h"

rbx::datamodel rbx::task_scheduler::get_datamodel() {
	auto fake = read<uint64_t>(driver::roblox_base + offsets::FakeDataModelPointer);
	auto dm = read<uint64_t>(fake + offsets::FakeDataModelToDataModel);
	return datamodel(dm);
}

rbx::visual_engine rbx::task_scheduler::get_visual_engine() {
	auto ve = read<uint64_t>(driver::roblox_base + offsets::VisualEnginePointer);
	return visual_engine(ve);
}