#pragma once
#include "classes/instance/instance.h"

namespace rbx {
	struct part : instance {
		instance get_part_primitive();
		vector3_t get_part_position();
		matrix3_t get_part_rotation();
		int get_distance(part target_part);
	};
}