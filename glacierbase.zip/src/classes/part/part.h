#pragma once
#include "classes/instance/instance.h"

namespace rbx {
	struct part : instance {
		instance get_part_primitive();
		vector3_t get_part_position();
		matrix3_t get_part_rotation();
		vector3_t get_part_velocity();
		float get_distance(part target_part);

		bool set_part_position(vector3_t pos);
		bool set_part_rotation(matrix3_t rot);
		bool set_part_velocity(vector3_t velocity);
	};
}