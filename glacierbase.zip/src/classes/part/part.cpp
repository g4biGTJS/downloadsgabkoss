#include "part.h"

rbx::instance rbx::part::get_part_primitive() {
	auto prim = read<uint64_t>(this->self + offsets::Primitive);
	return instance(prim);
}

rbx::vector3_t rbx::part::get_part_position() {
	auto prim = this->get_part_primitive();
	auto pos = read<vector3_t>(prim.self + offsets::Position);
	return pos;
}

rbx::matrix3_t rbx::part::get_part_rotation() {
	auto prim = this->get_part_primitive();
	auto rot = read<matrix3_t>(prim.self + offsets::Rotation);
	return rot;
}

int rbx::part::get_distance(part target_part) {
	auto a = this->get_part_position();
	auto b = target_part.get_part_position();
	auto x = (a.x - b.x) * (a.x - b.x);
	auto y = (a.y - b.y) * (a.y - b.y);
	auto z = (a.z - b.z) * (a.z - b.z);
	auto d = sqrt(x + y + z);
	return int(d);
}