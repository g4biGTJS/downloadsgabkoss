#include <windows.h>
#include <iostream>

#include "render/render.h"
#include "cheats/combat/combat.h"

int main() {
	SetConsoleTitle("External base <> version-889d2588b25a43d1");
	SetProcessDPIAware();

	printf("\n[*] This external base was KINDA(not) made by YuxGrahh.\n\n");

	{
		// driver init thx
		if (!driver::connect()) {
			printf("[-] Driver not found.\n");
			system("pause");
			return 1;
		}

		if (!driver::get_process_id("RobloxPlayerBeta.exe")) {
			printf("[-] Failed to get pid.\n");
			system("pause");
			return 1;
		}

		if (!driver::get_process_base()) {
			printf("[-] Failed to get roblox base.\n");
			system("pause");
			return 1;
		}

		printf("[*] Trying to find RobloxPlayerBeta.exe\n");
		sleep_ms(1000);
		printf("[*] RobloxPlayerBeta.exe found!\n");
		printf("[+] RobloxPlayerBeta.exe @ 0x%llx\n", driver::roblox_base);
		printf("[+] Roblox PID - %d\n", driver::roblox_process_id);
	}

	std::thread(rbx::cache::threads::globals_cache).detach();
	sleep_ms(500);
	std::thread(rbx::cache::threads::visuals_cache).detach();
	std::thread(rbx::cache::threads::combat_cache).detach();

	std::thread(combat::combat_thread).detach();
	renderer::draw();

	system("pause");
	return 0;
}