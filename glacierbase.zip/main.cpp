#include <windows.h>
#include <iostream>

#include "render/render.h"
#include "cheats/combat/combat.h"

int main() {
	SetConsoleTitle("external - kakav");
	SetProcessDPIAware();

	printf("[*] welcome kakav.\n");

	{
		// driver init thx
		if (!driver::connect()) {
			printf("[-] driver not found.\n");
			system("pause");
			return 1;
		}

		if (!driver::get_process_id("RobloxPlayerBeta.exe")) {
			printf("[-] failed to get pid.\n");
			system("pause");
			return 1;
		}

		if (!driver::get_process_base()) {
			printf("[-] failed to get roblox base.\n");
			system("pause");
			return 1;
		}

		printf("[*] robloxplayerbeta.exe found!\n");
		printf("[+] robloxplayerbeta.exe @ 0x%llx\n", driver::roblox_base);
		printf("[+] roblox pid - %d\n", driver::roblox_process_id);
	}

	std::thread(rbx::cache::threads::globals_cache).detach();
	sleep_ms(500); // slight wait
	std::thread(rbx::cache::threads::visuals_cache).detach();
	std::thread(rbx::cache::threads::combat_cache).detach();

	std::thread(combat::combat_thread).detach();
	renderer::draw();

	system("pause");
	return 0;
}